<?php
 
namespace App\Http\Controllers\Auth;

use App\User;
use Illuminate\Support\Str;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected function redirectTo()
    {
        return url()->previous();
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'lastname' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:255'],
            'dni' => ['required', 'string', 'max:255'],
            'address' =>['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
       $count=User::where('name', $data['name'])->where('lastname', $data['lastname'])->count();
        $slug=Str::slug($data['name']." ".$data['lastname'], '-');
        if ($count>0) {
            $slug=$slug."-".$count;
        }

        // Validación para que no se repita el slug
        $num=0;
        while (true) {
            $count2=User::where('slug', $slug)->count();
            if ($count2>0) {
                $slug=$slug."-".$num;
                $num++;
            } else {
                break;
            }
        }

         // Mover imagen a carpeta users y extraer nombre
        if ($request->hasFile('photo')) {
            $file = $request->file('photo');
            $photo = time()."_".$file->getClientOriginalName();
            $file->move(public_path().'/web/images/users/', $photo);
            $data['photo'] = $photo;
        }

        return User::create([
            'name' => $data['name'],
            'lastname' => $data['lastname'],
            'slug' => $slug,
            'phone' => $data['phone'],
            'email' => $data['email'],
            'dni' => $data['dni'],
            'address' => $data['address'],
            'photo' => $data['photo'],
            'password' => Hash::make($data['password']),

        ]);
    }
}
