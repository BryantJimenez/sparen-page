<?php if(session('type') && session('title') && session('msg')): ?>
<script type="text/javascript">
	Lobibox.notify('<?php echo e(session('type')); ?>', {
		title: '<?php echo e(session('title')); ?>',
		sound: true,
		msg: '<?php echo e(session('msg')); ?>'
	});
</script>
<?php endif; ?><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/partials/notifications.blade.php ENDPATH**/ ?>