<?php $__env->startSection('title', __('messages.binnacle')); ?>

<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/web/vendors/datatables/jquery.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="bradcam_area breadcam_bg_2">
	<div class="container">
		<div class="row">
			<div class="col-xl-12">
				<div class="bradcam_text text-center">
					<h3><?php echo app('translator')->getFromJson('messages.binnacle'); ?></h3>
				</div>
			</div>
		</div>
	</div>
</div>

<section class="contact-section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<table id="<?php if($lang=="es"): ?><?php echo e("tabla"); ?><?php else: ?><?php echo e("table-en"); ?><?php endif; ?>" class="table table-striped">
					<thead>
						<tr>
							<th scope="col">#</th>
							<th scope="col"><?php echo app('translator')->getFromJson('messages.user'); ?></th>
							<th scope="col"><?php echo app('translator')->getFromJson('messages.activity'); ?></th>
							<th scope="col"><?php echo app('translator')->getFromJson('messages.date'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $binnacle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th scope="row"><?php echo e($num++); ?></th>
							<td><?php echo e($b->user->name." ".$b->user->lastname); ?></td>
							<td><?php echo e($b->activity); ?></td>
							<td><?php echo e($b->created_at); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('/web/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/binnacle.blade.php ENDPATH**/ ?>