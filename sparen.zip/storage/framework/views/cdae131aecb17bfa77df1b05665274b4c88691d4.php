<!DOCTYPE html>
<html lang="<?php echo e($lang); ?>">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Compañía especializada en brindar consultorías en Economía, Finanzas e Inversión a Empresas, Inversores e Instituciones.">
	<meta name="keywords" content="Economía, Finanzas, Inversión">
	<meta property="og:title" content="Sparen | Economía, Finanzas e Inversión" />
	<meta property="og:description" content="Compañía especializada en brindar consultorías en Economía, Finanzas e Inversión a Empresas, Inversores e Instituciones." />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="http://www.sparen.com.ar" />
	<meta property="og:image" content="http://www.sparen.pe/web/images/about/logo.jpg" />
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('/web/images/favicon.ico')); ?>">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title><?php echo $__env->yieldContent('title'); ?></title>

	<link rel="stylesheet" href="<?php echo e(asset('/web/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/web/css/owl.carousel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/web/css/magnific-popup.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/web/css/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/web/css/themify-icons.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/web/css/flaticon.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/web/css/animate.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/web/css/slicknav.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/web/css/style.css')); ?>">

	<?php echo $__env->yieldContent('links'); ?>
</head>

<body>	

	<?php echo $__env->make('web.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('web.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	<script src="<?php echo e(asset('/web/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/web/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/web/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/web/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/web/js/owl.carousel.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/web/js/wow.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/web/js/jquery.slicknav.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/web/js/jquery.magnific-popup.min.js')); ?>"></script>

	<?php echo $__env->yieldContent('script'); ?>
	<script src="<?php echo e(asset('/web/js/main.js')); ?>"></script>

	<?php echo $__env->make('web.partials.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/layouts/web.blade.php ENDPATH**/ ?>