<footer class="footer">
    <div class="footer_top">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-md-6 col-lg-4">
                    <div class="footer_widget">
                        <div class="footer_logo">
                            <a href="#">
                                <img src="<?php echo e(asset('/web/images/logo.png')); ?>" alt="Logo" width="180">
                            </a>
                        </div>
                        <p><?php echo app('translator')->getFromJson('messages.description'); ?></p>

                    </div>
                </div>
                <div class="col-xl-2 offset-xl-1 col-md-6 col-lg-3">
                    <div class="footer_widget">
                        <h3 class="footer_title">
                            <?php echo app('translator')->getFromJson('messages.services'); ?>
                        </h3> 
                        <ul>
                            <li><a href="/<?php echo e($lang); ?>/#servicios"><?php echo app('translator')->getFromJson('messages.services'); ?></a></li>
                            <li><a href="/<?php echo e($lang); ?>/#sobre"><?php echo app('translator')->getFromJson('messages.about'); ?></a></li>
                        </ul>

                    </div>
                </div>
                <div class="col-xl-2 col-md-6 col-lg-2">
                    <div class="footer_widget">
                        <h3 class="footer_title">
                            <?php echo app('translator')->getFromJson('messages.pages'); ?>
                        </h3>
                        <ul>
                            <li><a href="<?php echo e(route('informe.index', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.reports'); ?></a></li>
                            <li><a href="<?php echo e(route('contacto.index', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.contact'); ?></a></li>
                            <?php if(auth()->guard()->guest()): ?>
                            <li><a class="popup-with-form" href="#test-form"><?php echo app('translator')->getFromJson('messages.login'); ?></a></li>
                            <?php else: ?>
                            <li><a class="popup-with-form" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo app('translator')->getFromJson('messages.logout'); ?></a></li>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 col-lg-3">
                    <div class="footer_widget">
                        <h3 class="footer_title">
                            <?php echo app('translator')->getFromJson('messages.address'); ?>
                        </h3>
                        <ul>
                            <li><?php echo e($info->address); ?></li>
                            <?php if($info->phone!=NULL): ?>
                            <li><?php echo e($info->phone); ?></li>
                            <?php endif; ?>
                            <?php if($info->email!=NULL): ?>
                            <li><?php echo e($info->email); ?></li>
                            <?php endif; ?>
                            <?php if($info->facebook!=NULL): ?>
                            <li><i class="ti-facebook"></i> <?php echo e($info->facebook); ?></li>
                            <?php endif; ?>
                            <?php if($info->twitter!=NULL): ?>
                            <li><i class="ti-twitter"></i> <?php echo e($info->twitter); ?></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copy-right_text">
        <div class="container">
            <div class="footer_border"></div>
            <div class="row">
                <div class="col-xl-12">
                    <p class="copy_right text-center">Sparen &copy;<script>document.write(new Date().getFullYear());</script> <?php echo app('translator')->getFromJson('messages.copyright'); ?> | <?php echo app('translator')->getFromJson('messages.make'); ?> <a href="https://www.otterscompany.com" target="_blank">Otters Company <i class="fa fa-heart-o" aria-hidden="true"></i></a></p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--/ footer end  -->

<!-- form itself end-->
<form id="test-form" class="white-popup-block mfp-hide"method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <div class="popup_box ">
        <div class="popup_inner">
            <div class="popup_header">
                <h3><?php echo app('translator')->getFromJson('messages.login'); ?></h3>
            </div>
            <div class="custom_form">
                <div class="row">
                    <div class="col-xl-12">
                        <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="<?php echo app('translator')->getFromJson('messages.enter your email'); ?>">

                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                    </div>
                    <div class="col-xl-12">
                        <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password" placeholder="<?php echo app('translator')->getFromJson('messages.enter your password'); ?>" >

                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-xl-12">
                        <button type="submit" action="login" class="boxed-btn3"><?php echo app('translator')->getFromJson('messages.sign in'); ?></button>
                    </div>
               </div>
           </div>
       </div>
   </div>
</form>
 <!-- form itself end --><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/partials/footer.blade.php ENDPATH**/ ?>