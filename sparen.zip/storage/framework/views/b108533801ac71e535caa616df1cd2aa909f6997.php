<?php $__env->startSection('title', __('messages.user registration')); ?>

<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/web/vendors/dropify/css/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="bradcam_area breadcam_bg_5">
	<div class="container">
		<div class="row">
			<div class="col-xl-12">
				<div class="bradcam_text text-center">
					<h3><?php echo app('translator')->getFromJson('messages.user registration'); ?></h3>
				</div>
			</div>
		</div>
	</div>
</div>

<section class="contact-section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-body">
						<?php echo $__env->make('web.partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<h3 class="text-heading"><?php echo app('translator')->getFromJson('messages.user registration'); ?></h3>

						<h6 class="card-subtitle"><?php echo app('translator')->getFromJson('messages.required fields'); ?> (<b class="text-danger">*</b>)</h6>
						<form  method="POST" class="form" action="<?php echo e(route('usuario.store', ['lang' => $lang])); ?>" enctype="multipart/form-data" id="formUser">
							<?php echo csrf_field(); ?>
							<div class="row">
								<div class="form-group col-lg-6 col-md-6 col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.name'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="text" name="name" required placeholder="<?php echo app('translator')->getFromJson('messages.enter a name'); ?>" value="<?php echo e(old('name')); ?>" id="name" minlength="2" maxlength="191">
								</div>

								<div class="form-group col-lg-6 col-md-6 col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.lastname'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="text" name="lastname" required placeholder="<?php echo app('translator')->getFromJson('messages.enter a lastname'); ?>" value="<?php echo e(old('lastname')); ?>" minlength="2" maxlength="191">
								</div>

								<div class="form-group col-lg-6 col-md-6 col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.dni'); ?> (<?php echo app('translator')->getFromJson('messages.optional'); ?>)</label>
									<input class="form-control" type="text" name="dni" placeholder="<?php echo app('translator')->getFromJson('messages.enter a dni'); ?>" value="<?php echo e(old('dni')); ?>" minlength="5" maxlength="15">
								</div>

								<div class="form-group col-lg-6 col-md-6 col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.email'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="email" name="email" required placeholder="<?php echo app('translator')->getFromJson('messages.enter a email'); ?>" value="<?php echo e(old('email')); ?>" minlength="5" maxlength="191">
								</div>


								<div class="form-group col-lg-6 col-md-6 col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.address'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="text" name="address" required placeholder="<?php echo app('translator')->getFromJson('messages.enter a address'); ?>" value="<?php echo e(old('address')); ?>" minlength="5" maxlength="191">
								</div>

								<div class="form-group col-lg-6 col-md-6 col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.phone'); ?> (<?php echo app('translator')->getFromJson('messages.optional'); ?>)</label>
									<input class="form-control" type="text" name="phone" placeholder="<?php echo app('translator')->getFromJson('messages.enter a phone'); ?>" value="<?php echo e(old('phone')); ?>" id="phone" minlength="5" maxlength="15">
								</div>

								<div class="form-group col-lg-6 col-md-6 col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.password'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="password" name="password" required placeholder="********" id="password" minlength="8" maxlength="40">
								</div>

								<div class="form-group col-lg-6 col-md-6 col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.confirm password'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="password" name="password_confirmation" required placeholder="********" minlength="8" maxlength="40">
								</div>

								<div class="form-group col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.photo'); ?> (<?php echo app('translator')->getFromJson('messages.optional'); ?>)</label>
									<input type="file" name="photo" accept="image/*" id="input-file-now" class="<?php if($lang=="es"): ?><?php echo e('dropify'); ?><?php else: ?><?php echo e('dropifys'); ?><?php endif; ?>" data-height="125" data-max-file-size="20M" data-allowed-file-extensions="jpg png jpeg web3" />
								</div> 

								<div class="form-group col-12">
									<div class="btn-group" role="group">
										<button type="submit" class="btn btn-primary" action="user"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
									</div>
								</div>

							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('/web/vendors/dropify/js/dropify.min.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/additional-methods.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/messages_es.js')); ?>"></script>
<script src="<?php echo e(asset('/web/js/validate.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/users/create.blade.php ENDPATH**/ ?>