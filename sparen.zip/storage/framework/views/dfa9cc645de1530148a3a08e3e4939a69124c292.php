<?php $__env->startSection('title', __('messages.user list')); ?>

<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/web/vendors/datatables/jquery.dataTables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/web/vendors/lobibox/Lobibox.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="bradcam_area breadcam_bg_6">
	<div class="container">
		<div class="row">
			<div class="col-xl-12">
				<div class="bradcam_text text-center">
					<h3><?php echo app('translator')->getFromJson('messages.user list'); ?></h3>
				</div>
			</div>
		</div>
	</div>
</div>

<section class="contact-section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<table id="<?php if($lang=="es"): ?><?php echo e("tabla"); ?><?php else: ?><?php echo e("table-en"); ?><?php endif; ?>" class="table table-striped">
					<thead>
						<tr>
							<th scope="col">#</th>
							<th scope="col"><?php echo app('translator')->getFromJson('messages.full name'); ?></th>
							<th scope="col"><?php echo app('translator')->getFromJson('messages.email'); ?></th>
							<th scope="col"><?php echo app('translator')->getFromJson('messages.dni'); ?></th>
							<th scope="col"><?php echo app('translator')->getFromJson('messages.actions'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th scope="row"><?php echo e($num++); ?></th>
							<td><?php echo e($user->name." ".$user->lastname); ?></td>
							<td><?php echo e($user->email); ?></td>
							<td><?php echo e($user->dni); ?></td>
							<td class="d-flex">
								<a class="btn btn-info btn-circle btn-sm" data-toggle="tooltip" data-placement="bottom" title="<?php echo app('translator')->getFromJson('messages.edit'); ?>" href="<?php echo e(route('usuario.edit', ['slug' => $user->slug, 'lang' => $lang])); ?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('/web/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/lobibox/Lobibox.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/users/index.blade.php ENDPATH**/ ?>