<?php $__env->startSection('title', __('messages.edit info contact')); ?>

<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/web/vendors/lobibox/Lobibox.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- bradcam_area  -->
<div class="bradcam_area breadcam_bg_5">
	<div class="container">
		<div class="row">
			<div class="col-xl-12">
				<div class="bradcam_text text-center">
					<h3><?php echo app('translator')->getFromJson('messages.edit info contact'); ?></h3>
				</div>
			</div>
		</div>
	</div> 
</div>
<!--/ bradcam_area  -->

<!-- ================ contact section start ================= -->
<section class="contact-section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-body"> 
						<?php echo $__env->make('web.partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<h3 class="text-heading"><?php echo app('translator')->getFromJson('messages.edit info contact'); ?></h3>
						<form class="form-contact contact_form" action="<?php echo e(route('contacto.update', ['lang' => $lang])); ?>" method="POST" id="formInfoContact">
							<?php echo method_field('PUT'); ?>
							<?php echo csrf_field(); ?>
							<div class="row">
								<div class="col-sm-12">
									<div class="form-group">
										<label class="col-form-label"><span class="contact-info__icon"><i class="ti-home"></i></span><?php echo app('translator')->getFromJson('messages.address'); ?><b class="text-danger">*</b></label>
										<input class="form-control valid" name="address" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = '<?php echo app('translator')->getFromJson('messages.enter your address'); ?>'" placeholder="<?php echo app('translator')->getFromJson('messages.enter your address'); ?>" value="<?php echo e($info->address); ?>">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label class="col-form-label"><span class="contact-info__icon"><i class="ti-tablet"></i></span><?php echo app('translator')->getFromJson('messages.phone'); ?> (Opcional)</label>
										<input class="form-control valid" name="phone" id="phone" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = '<?php echo app('translator')->getFromJson('messages.enter your phone'); ?>'" placeholder="<?php echo app('translator')->getFromJson('messages.enter your phone'); ?>" value="<?php echo e($info->phone); ?>">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label class="col-form-label"><span class="contact-info__icon"><i class="ti-email"></i></span><?php echo app('translator')->getFromJson('messages.email'); ?> (Opcional)</label>
										<input class="form-control valid" name="email" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = '<?php echo app('translator')->getFromJson('messages.enter your email'); ?>'" placeholder="<?php echo app('translator')->getFromJson('messages.enter your email'); ?>" value="<?php echo e($info->email); ?>">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label class="col-form-label"><span class="contact-info__icon"><i class="ti-facebook"></i></span>Facebook (Opcional)</label>
										<input class="form-control valid" name="facebook" type="text" onfocus="this.placeholder = 'Facebook'" onblur="this.placeholder = 'Facebook'" placeholder="Facebook" value="<?php echo e($info->facebook); ?>">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<label class="col-form-label"><span class="contact-info__icon"><i class="ti-twitter"></i></span>Twitter (Opcional)</label>
										<input class="form-control valid" name="twitter" type="text" onfocus="this.placeholder = 'Twitter'" onblur="this.placeholder = 'Twitter'" placeholder="Twitter" value="<?php echo e($info->twitter); ?>">
									</div>
								</div>
							</div>
							<div class="form-group mt-3">
								<button type="submit" action="infoContact" class="button button-contactForm boxed-btn"><?php echo app('translator')->getFromJson('messages.send'); ?></button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- ================ contact section end ================= -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('/web/vendors/lobibox/Lobibox.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/additional-methods.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/messages_es.js')); ?>"></script>
<script src="<?php echo e(asset('/web/js/validate.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/contact/edit.blade.php ENDPATH**/ ?>