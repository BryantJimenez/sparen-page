<?php $__env->startSection('title', 'Sparen'); ?>

<?php $__env->startSection('content'); ?>

<!-- slider_area_start -->
<div class="slider_area">
    <div class="slider_active owl-carousel">
        <div class="single_slider d-flex align-items-center slider_bg_2 overlay2" style="background-image: url(/web/images/banner/<?php echo e($banner->picture1); ?>);">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="slider_text ">
                            <h3><?php if($lang=="es"): ?> <?php echo $banner->banner1_spanish; ?> <?php else: ?> <?php echo $banner->banner1_english; ?> <?php endif; ?></h3>
                        </div>
                        <?php if(auth()->guard()->guest()): ?>
                        <?php else: ?>
                        <div class="video_service_btn">
                            <a href="<?php echo e(route('banner.edit', ['lang' => $lang])); ?>" class="boxed-btn3"><?php echo app('translator')->getFromJson('messages.edit'); ?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="single_slider  d-flex align-items-center slider_bg_1 overlay2" style="background-image: url(/web/images/banner/<?php echo e($banner->picture2); ?>);">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="slider_text ">
                            <h3><?php if($lang=="es"): ?> <?php echo $banner->banner2_spanish; ?> <?php else: ?> <?php echo $banner->banner2_english; ?> <?php endif; ?></h3>
                        </div>
                        <?php if(auth()->guard()->guest()): ?>
                        <?php else: ?>
                        <div class="video_service_btn">
                            <a href="<?php echo e(route('banner.edit', ['lang' => $lang])); ?>" class="boxed-btn3"><?php echo app('translator')->getFromJson('messages.edit'); ?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="single_slider  d-flex align-items-center slider_bg_3 overlay2" style="background-image: url(/web/images/banner/<?php echo e($banner->picture3); ?>);">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="slider_text ">
                            <h3><?php if($lang=="es"): ?> <?php echo $banner->banner3_spanish; ?> <?php else: ?> <?php echo $banner->banner3_english; ?> <?php endif; ?></h3>
                        </div>
                        <?php if(auth()->guard()->guest()): ?>
                        <?php else: ?>
                        <div class="video_service_btn">
                            <a href="<?php echo e(route('banner.edit', ['lang' => $lang])); ?>" class="boxed-btn3"><?php echo app('translator')->getFromJson('messages.edit'); ?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- slider_area_end -->

<!-- about  -->
<div class="about_area pt-5">
    <div class="container-fluid">
        <div class="row no-gutters align-items-center">
            <div class="col-xl-6 col-lg-6">
                <div class="about_image">
                    <a  name="sobre" id="sobre"> <img src="<?php echo e(asset('/web/images/about/'.$about->picture)); ?>" alt=""></a>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">
                <div class="about_info">
                    <h3><?php echo app('translator')->getFromJson('messages.about us'); ?></h3>
                    <p><?php if($lang=="es"): ?> <?php echo $about->paragraph_spanish; ?> <?php else: ?> <?php echo $about->paragraph_english; ?> <?php endif; ?></p>
                    <ul>
                        <li><?php if($lang=="es"): ?> <?php echo e($about->list1_spanish); ?> <?php else: ?> <?php echo e($about->list1_english); ?> <?php endif; ?></li>
                        <li><?php if($lang=="es"): ?> <?php echo e($about->list2_spanish); ?> <?php else: ?> <?php echo e($about->list2_english); ?> <?php endif; ?></li>
                        <li><?php if($lang=="es"): ?> <?php echo e($about->list3_spanish); ?> <?php else: ?> <?php echo e($about->list3_english); ?> <?php endif; ?></li>
                        <li><?php if($lang=="es"): ?> <?php echo e($about->list4_spanish); ?> <?php else: ?> <?php echo e($about->list4_english); ?> <?php endif; ?></li>
                    </ul>

                    <?php if(auth()->guard()->guest()): ?>         
                    <?php else: ?>     
                    <div class="video_service_btn">
                        <a href="<?php echo e(route('sobre.edit', ['lang' => $lang])); ?>" class="boxed-btn3"><?php echo app('translator')->getFromJson('messages.edit'); ?></a>
                    </div>
                    <?php endif; ?>             
                    <br>

                </div>
            </div>
        </div>
    </div>
</div>
<!--/ about  -->

<!-- service_area_start -->
<div class="service_area pt-2">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="section_title text-center mb-50">
                    <h3> <a  name="servicios" id="servicios" ><?php echo app('translator')->getFromJson('messages.our services'); ?></a></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-4 col-md-4">
                <div class="single_service" style="background-image: url(/web/images/service/<?php echo e($service->picture1); ?>);">
                    <div class="service_hover">
                        <img src="<?php echo e(asset('/web/images/svg_icon/legal-paper.svg')); ?>" alt="">
                        <h3><?php if($lang=="es"): ?> <?php echo e($service->title1_spanish); ?> <?php else: ?> <?php echo e($service->title1_english); ?> <?php endif; ?></h3>
                        <div class="hover_content">
                            <div class="hover_content_inner">
                                <h4><?php if($lang=="es"): ?> <?php echo e($service->title1_spanish); ?> <?php else: ?> <?php echo e($service->title1_english); ?> <?php endif; ?></h4>
                                <p><?php if($lang=="es"): ?> <?php echo e($service->content1_spanish); ?> <?php else: ?> <?php echo e($service->content1_english); ?> <?php endif; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-4">
                <div class="single_service" style="background-image: url(/web/images/service/<?php echo e($service->picture2); ?>);">
                    <div class="service_hover">
                        <img src="<?php echo e(asset('/web/images/svg_icon/case.svg')); ?>" alt="">
                        <h3><?php if($lang=="es"): ?> <?php echo e($service->title2_spanish); ?> <?php else: ?> <?php echo e($service->title2_english); ?> <?php endif; ?></h3>
                        <div class="hover_content">
                            <div class="hover_content_inner">
                                <h4><?php if($lang=="es"): ?> <?php echo e($service->title2_spanish); ?> <?php else: ?> <?php echo e($service->title2_english); ?> <?php endif; ?></h4>
                                <p><?php if($lang=="es"): ?> <?php echo e($service->content2_spanish); ?> <?php else: ?> <?php echo e($service->content2_english); ?> <?php endif; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-4">
                <div class="single_service" style="background-image: url(/web/images/service/<?php echo e($service->picture3); ?>);">
                    <div class="service_hover">
                        <img src="<?php echo e(asset('/web/images/svg_icon/survey.svg')); ?>" alt="">
                        <h3><?php if($lang=="es"): ?> <?php echo e($service->title3_spanish); ?> <?php else: ?> <?php echo e($service->title3_english); ?> <?php endif; ?></h3>
                        <div class="hover_content">
                            <div class="hover_content_inner">
                                <h4><?php if($lang=="es"): ?> <?php echo e($service->title3_spanish); ?> <?php else: ?> <?php echo e($service->title3_english); ?> <?php endif; ?></h4>
                                <p><?php if($lang=="es"): ?> <?php echo e($service->content3_spanish); ?> <?php else: ?> <?php echo e($service->content3_english); ?> <?php endif; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>
        <div class="video_service_btn">
            <a href="<?php echo e(route('servicio.edit', ['lang' => $lang])); ?>" class="boxed-btn3"><?php echo app('translator')->getFromJson('messages.edit'); ?></a>
        </div>
        <?php endif; ?>
    </div>
</div>
<!-- service_area_end -->

<!-- about wrap  -->
<div class="about_wrap_area" style="background-image: url(/web/images/objective/<?php echo e($objective->picture); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-md-6 col-lg-4">
                <div class="single_service_wrap text-center">
                    <img src="<?php echo e(asset('/web/images/svg_icon/controls.svg')); ?>" alt="Controles">
                    <h3><?php if($lang=="es"): ?> <?php echo e($objective->title1_spanish); ?> <?php else: ?> <?php echo e($objective->title1_english); ?> <?php endif; ?></h3>
                    <p><?php if($lang=="es"): ?> <?php echo $objective->content1_spanish; ?> <?php else: ?> <?php echo $objective->content1_english; ?> <?php endif; ?></p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 col-lg-4">
                <div class="single_service_wrap text-center">
                    <img src="<?php echo e(asset('/web/images/svg_icon/bar-chart.svg')); ?>" alt="Gráficas">
                    <h3><?php if($lang=="es"): ?> <?php echo e($objective->title2_spanish); ?> <?php else: ?> <?php echo e($objective->title2_english); ?> <?php endif; ?></h3>
                    <p><?php if($lang=="es"): ?> <?php echo $objective->content2_spanish; ?> <?php else: ?> <?php echo $objective->content2_english; ?> <?php endif; ?></p>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 col-lg-4">
                <div class="single_service_wrap text-center">
                    <img src="<?php echo e(asset('/web/images/svg_icon/puzzle.svg')); ?>" alt="Inversión">
                    <h3><?php if($lang=="es"): ?> <?php echo e($objective->title3_spanish); ?> <?php else: ?> <?php echo e($objective->title3_english); ?> <?php endif; ?></h3>
                    <p><?php if($lang=="es"): ?> <?php echo $objective->content3_spanish; ?> <?php else: ?> <?php echo $objective->content3_english; ?> <?php endif; ?></p>
                </div>
            </div>
        </div>
        <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>
        <div class="video_service_btn">
            <a href="<?php echo e(route('objetivo.edit', ['lang' => $lang])); ?>" class="boxed-btn3"><?php echo app('translator')->getFromJson('messages.edit'); ?></a>
        </div>
        <?php endif; ?>
    </div>
</div> 
<!--/ about wrap  -->


<!-- financial_solution -->

<!--/ financial_solution -->

<!-- project  -->
<div class="project_area">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="project_info text-center">
                    <h3><?php echo app('translator')->getFromJson('messages.do you have any project'); ?></h3>
                    <p><?php echo app('translator')->getFromJson('messages.we will be happy to help you in everything you need'); ?></p>
                    <a href="<?php echo e(route('contacto.index', ['lang' => $lang])); ?>" class="boxed-btn3-white"><?php echo app('translator')->getFromJson('messages.contact us'); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--/ project  -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('/web/vendors/validate/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/additional-methods.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/messages_es.js')); ?>"></script>
<script src="<?php echo e(asset('/web/js/validate.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/home.blade.php ENDPATH**/ ?>