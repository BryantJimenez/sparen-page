<?php $__env->startSection('title', __('messages.reports')); ?>

<?php $__env->startSection('content'); ?>

<!-- bradcam_area  -->
<div class="bradcam_area breadcam_bg_report">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="bradcam_text text-center">
                    <h3><?php echo app('translator')->getFromJson('messages.reports'); ?></h3>
                </div>
            </div>
        </div>
    </div>
</div>
<!--/ bradcam_area  -->

<section class="blog_area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0 order-xl-1 order-lg-1 order-md-2 order-sm-2">
                <div class="blog_left_sidebar">
                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <article class="blog_item">

                        <div class="blog_details">
                            <a class="d-inline-block">
                                <h2><?php if($lang=="es"): ?> <?php echo e($r->title_spanish); ?> <?php else: ?> <?php echo e($r->title_english); ?> <?php endif; ?></h2>
                            </a>
                            <p><?php if($lang=="es"): ?> <?php echo e($r->description_spanish); ?> <?php else: ?> <?php echo e($r->description_english); ?> <?php endif; ?></p>
                            <ul class="blog-info-link">
                                <li><a href="#"><i class="fa fa-user"></i><?php echo e($r->user->name." ".$r->user->lastname); ?></a></li>
                                <li><a href='<?php if($lang=="es"): ?><?php echo e(asset('/web/images/reports/'.$r->pdf_spanish)); ?><?php else: ?><?php echo e(asset('/web/images/reports/'.$r->pdf_english)); ?><?php endif; ?>'><i class="fa fa-download"></i> <?php echo app('translator')->getFromJson('messages.download'); ?></a></li>
                            </ul>
                        </div>
                    </article>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <nav class="blog-pagination justify-content-center d-flex">
                        <?php echo $reports->render(); ?>

                    </nav>

                </div>
            </div>
            <div class="col-lg-4 order-xl-2 order-lg-2 order-md-1 order-sm-1">
                <div class="blog_right_sidebar">
                    <aside class="single_sidebar_widget search_widget">
                        <form action="#">
                            <div class="form-group">
                                <div class="input-group mb-3">
                                    <input type="search" name="report" class="form-control" aria-label="<?php echo app('translator')->getFromJson('messages.search'); ?>" placeholder="<?php echo app('translator')->getFromJson('messages.enter the title of a report'); ?>">
                                    <div class="input-group-append">
                                        <button class="btn" type="button"><i class="ti-search"></i></button>
                                    </div>
                                </div>
                            </div>
                            <button class="button rounded-0 primary-bg text-white w-100 btn_1 boxed-btn"
                            type="submit"><?php echo app('translator')->getFromJson('messages.search'); ?></button>
                        </form>
                    </aside>
                    
                    <?php if(auth()->guard()->guest()): ?>
                    <?php else: ?>
                    <aside class="single_sidebar_widget newsletter_widget">
                        <h4 class="widget_title"><?php echo app('translator')->getFromJson('messages.register a new report'); ?></h4>
                        <a href=" <?php echo e(route('informe.create', ['lang' => $lang])); ?> "><button class="button rounded-0 primary-bg text-white w-100 btn_1 boxed-btn"><?php echo app('translator')->getFromJson('messages.register'); ?></button></a>
                    </aside>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================Blog Area =================-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('/web/vendors/validate/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/additional-methods.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/messages_es.js')); ?>"></script>
<script src="<?php echo e(asset('/web/js/validate.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/reports/index.blade.php ENDPATH**/ ?>