<?php $__env->startSection('title', __('messages.registration of report')); ?>

<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/web/vendors/dropify/css/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="bradcam_area breadcam_bg_5">
	<div class="container">
		<div class="row">
			<div class="col-xl-12">
				<div class="bradcam_text text-center">
					<h3><?php echo app('translator')->getFromJson('messages.registration of report'); ?></h3>
				</div>
			</div>
		</div>
	</div>
</div>

<section class="contact-section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-body">
						<?php echo $__env->make('web.partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<h6 class="card-subtitle"><?php echo app('translator')->getFromJson('messages.required fields'); ?> (<b class="text-danger">*</b>)</h6>
						<form  method="POST" action="<?php echo e(route('informe.store', ['lang' => $lang])); ?>" class="form" enctype="multipart/form-data" id="formReport">
							<?php echo csrf_field(); ?>
							<div class="row">
								<div class="form-group col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.title spanish'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="text" name="title_spanish" required placeholder="" value="<?php echo e(old('title_spanish')); ?>" minlength="2" maxlength="191">
								</div>

								<div class="form-group col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.title english'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="text" name="title_english" required placeholder="" value="<?php echo e(old('title_english')); ?>" minlength="2" maxlength="191">
								</div>

								<div class="form-group col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.description spanish'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="text"  name="description_spanish" required placeholder="" value="<?php echo e(old('description_spanish')); ?>" minlength="5" maxlength="191">
								</div>

								<div class="form-group col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.description english'); ?><b class="text-danger">*</b></label>
									<input class="form-control" type="text"  name="description_english" required placeholder="" value="<?php echo e(old('description_english')); ?>" minlength="5" maxlength="191">
								</div>

								<div class="form-group col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.archive spanish'); ?><b class="text-danger">*</b></label>
									<input type="file" name="pdf_spanish" required accept="application/pdf" class="<?php if($lang=="es"): ?><?php echo e('dropify'); ?><?php else: ?><?php echo e('dropifys'); ?><?php endif; ?>" data-allowed-file-extensions="pdf" />
								</div>

								<div class="form-group col-12">
									<label class="col-form-label"><?php echo app('translator')->getFromJson('messages.archive english'); ?><b class="text-danger">*</b></label>
									<input type="file" name="pdf_english" required accept="application/pdf" class="<?php if($lang=="es"): ?><?php echo e('dropify'); ?><?php else: ?><?php echo e('dropifys'); ?><?php endif; ?>" data-allowed-file-extensions="pdf" />
								</div>

								<div class="form-group col-12">
									<div class="btn-group" role="group">
										<button type="submit" class="btn btn-primary" action="report"><?php echo app('translator')->getFromJson('messages.save'); ?></button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('/web/vendors/dropify/js/dropify.min.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/additional-methods.js')); ?>"></script>
<script src="<?php echo e(asset('/web/vendors/validate/messages_es.js')); ?>"></script>
<script src="<?php echo e(asset('/web/js/validate.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/reports/create.blade.php ENDPATH**/ ?>