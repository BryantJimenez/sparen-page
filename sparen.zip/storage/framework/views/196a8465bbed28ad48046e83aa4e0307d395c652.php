<header>
    <div class="header-area ">
        <div id="sticky-header" class="main-header-area">
            <div class="container">
                <div class="header_bottom_border">
                    <div class="row align-items-center">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="<?php echo e(route('home')); ?>">
                                    <img src="<?php echo e(asset('/web/images/logo.png')); ?>" width="150" alt="Logo">
                                </a>
                            </div>
                        </div>
                        <?php if(auth()->guard()->guest()): ?> 
                        <div class="col-xl-8 col-lg-8">
                            <div class="main-menu  d-none d-lg-block">
                                <nav> 
                                    <ul id="navigation">
                                        <li><a class="active" href="<?php echo e(route('home', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.home'); ?></a></li>
                                        <li><a href="/<?php echo e($lang); ?>/#sobre"><?php echo app('translator')->getFromJson('messages.about'); ?></a></li>
                                        <li><a href="/<?php echo e($lang); ?>/#servicios"><?php echo app('translator')->getFromJson('messages.services'); ?></a></li>
                                        <li><a href="<?php echo e(route('informe.index', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.reports'); ?></a></li>
                                        <li><a href="<?php echo e(route('contacto.index', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.contact'); ?></a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="col-xl-8 col-lg-8">
                            <div class="main-menu  d-none d-lg-block">
                                <nav> 
                                    <ul id="navigation">
                                        <li><a class="active" href="<?php echo e(route('home', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.home'); ?></a></li>
                                        <li><a href="/<?php echo e($lang); ?>/#sobre"><?php echo app('translator')->getFromJson('messages.about'); ?></a></li>
                                        <li><a href="/<?php echo e($lang); ?>/#servicios"><?php echo app('translator')->getFromJson('messages.services'); ?></a></li>
                                        <li><a href="<?php echo e(route('informe.index', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.reports'); ?></a></li>
                                        <li><a href="<?php echo e(route('contacto.index', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.contact'); ?></a></li>
                                        <li><a href="<?php echo e(route('bitacora.index', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.binnacle'); ?></a></li>
                                        <li><a href="#"><?php echo app('translator')->getFromJson('messages.users'); ?><i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="<?php echo e(route('usuario.create', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.register'); ?></a></li>
                                                <li><a href="<?php echo e(route('usuario.index', ['lang' => $lang])); ?>"><?php echo app('translator')->getFromJson('messages.list'); ?></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="col-xl-2 col-lg-2 d-none d-lg-block">
                            <div class="Appointment">
                                <a href="<?php echo e(route('home', ['lang' => 'es'])); ?>"><img src="<?php echo e(asset('/web/images/spain.svg')); ?>" alt="Español" width="40" class="mr-3"></a>
                                <a href="<?php echo e(route('home', ['lang' => 'en'])); ?>"><img src="<?php echo e(asset('/web/images/english.jpg')); ?>" alt="Ingles" width="40"></a>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mobile_menu d-block d-lg-none"></div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</header>
<!-- header-end -->
<?php /**PATH C:\Users\USUARIO\Desktop\sparen\resources\views/web/partials/navbar.blade.php ENDPATH**/ ?>