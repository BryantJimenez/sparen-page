<?php echo e($slot); ?>

<?php /**PATH C:\Users\USUARIO\Desktop\sparen\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>